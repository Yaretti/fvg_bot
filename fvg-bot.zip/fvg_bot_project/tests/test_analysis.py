from fvg_bot.analysis import (
    find_bullish_fvgs, find_swings, nearest_active, pick_nearest, refresh_statuses, TfData, trend, zone_price, zone_status,
)
from fvg_bot.models import ZoneStatus, Zone, parse_klines
from tests.helpers import DOWNTREND, UPTREND, candles


def test_swings_and_uptrend():
    cs = candles(UPTREND)
    highs, lows = find_swings(cs, 1)
    assert [h for _, h in highs] == [16, 18]
    assert [l for _, l in lows] == [9, 10]
    assert trend(cs, 1).is_up


def test_downtrend_and_too_few_swings():
    assert not trend(candles(DOWNTREND), 1).is_up
    assert not trend(candles(UPTREND[:3]), 1).is_up


def test_open_candle_is_dropped():
    now_ms = 10_000
    raw = [[0, "1", "2", "1", "1", "1", 5_000], [5_001, "1", "2", "1", "1", "1", 15_000]]
    assert len(parse_klines(raw, now_ms)) == 1


def test_bullish_fvg_detection_bounds_and_minimum_gap():
    cs = candles([(90, 100), (95, 110), (101, 115)])  # High1=100 < Low3=101: 1% gap
    zs = find_bullish_fvgs("AAAUSDT", "4H", cs, min_gap_pct=0.6)
    assert len(zs) == 1
    z = zs[0]
    assert (z.lower, z.upper) == (100, 101)
    assert z.id == f"AAAUSDT:4H:{cs[0].open_time}" and z.formed_at == cs[2].close_time
    assert zone_price(z, "near") == 100 and zone_price(z, "far") == 101
    assert not find_bullish_fvgs("AAAUSDT", "4H", cs, min_gap_pct=1.1)


def test_no_fvg_when_overlap_equal_or_bearish():
    assert not find_bullish_fvgs("X", "4H", candles([(90, 100), (95, 110), (99, 100)]))
    assert not find_bullish_fvgs("X", "4H", candles([(100, 110), (90, 105), (80, 99)]))


def _zone(lower=11.0, upper=15.0):
    return Zone("id", "X", "4H", lower, upper, 0, 2)


def test_wick_into_zone_makes_it_not_untouched():
    z = _zone()
    assert zone_status(z, candles([(8, 9)]), 8.5) == ZoneStatus.UNTOUCHED
    assert zone_status(z, candles([(8, 10.9)]), 8.5) == ZoneStatus.UNTOUCHED
    assert zone_status(z, candles([(8, 11.0)]), 8.5) == ZoneStatus.PARTIAL
    assert zone_status(z, candles([(8, 13)]), 8.5) == ZoneStatus.PARTIAL
    assert zone_status(z, candles([(20, 22), (14, 22)]), 21.0) == ZoneStatus.PARTIAL


def test_live_price_in_zone_is_touch():
    z = _zone()
    assert zone_status(z, candles([(8, 9)]), 12.0) == ZoneStatus.PARTIAL
    assert zone_status(z, [], 11.0) == ZoneStatus.PARTIAL


def test_filled_by_single_or_combined_wicks():
    z = _zone()
    assert zone_status(z, candles([(10, 16)]), 8.0) == ZoneStatus.FILLED
    assert zone_status(z, candles([(10, 13), (12, 16)]), 8.0) == ZoneStatus.FILLED
    assert zone_status(z, candles([(10, 12), (14, 16)]), 8.0) == ZoneStatus.PARTIAL


def test_sticky_touch_and_open_candle_wick():
    cs = candles([(20, 25), (10, 20), (8, 12), (8, 11)])
    tf = TfData("4H", cs, [Zone("id", "X", "4H", 12, 20, 0, 2)], open_candle=candles([(9, 14)])[0])
    refresh_statuses(tf, 11.0)
    assert tf.zones[0].status == ZoneStatus.PARTIAL
    tf.open_candle = None
    refresh_statuses(tf, 8.0)
    assert tf.zones[0].status == ZoneStatus.UNTOUCHED
    refresh_statuses(tf, 8.0, touched={tf.zones[0].id})
    assert tf.zones[0].status == ZoneStatus.PARTIAL


def test_nearest_active_selection_and_distance_window():
    far = Zone("a", "X", "4H", 20, 30, 0, 2)
    near = Zone("b", "X", "4H", 11, 15, 0, 2)
    touched = Zone("c", "X", "4H", 12, 13, 0, 2, ZoneStatus.PARTIAL)
    filled = Zone("e", "X", "4H", 12, 13, 0, 2, ZoneStatus.FILLED)
    below = Zone("d", "X", "4H", 1, 2, 0, 2)
    around = Zone("f", "X", "4H", 8, 12, 0, 2)
    assert nearest_active([far, near, touched, filled, below, around], 9.0) is near
    assert nearest_active([near], 9.5, 5, 20) is near
    assert nearest_active([near], 10.5, 5, 20) is None  # ближче ніж 5%
    assert nearest_active([far], 9.0, 5, 20) is None  # далі ніж 20%
    assert nearest_active([touched, filled, below, around], 9.0) is None
    assert nearest_active([], 9.0) is None


def test_pick_nearest_between_timeframes():
    z1 = Zone("a", "X", "1D", 20, 30, 0, 2)
    z4 = Zone("b", "X", "4H", 11, 15, 0, 2)
    assert pick_nearest(z1, z4) is z4 and pick_nearest(z1, None) is z1 and pick_nearest(None, None) is None


def test_refresh_statuses_integration():
    cs = candles([(20, 25), (10, 20), (8, 12), (8, 11)])
    tf = TfData("4H", cs, [Zone("id", "X", "4H", 12, 20, 0, 2)])
    refresh_statuses(tf, 8.0)
    assert tf.zones[0].status == ZoneStatus.UNTOUCHED
    refresh_statuses(tf, 13.0)
    assert tf.zones[0].status == ZoneStatus.PARTIAL


def test_target_is_body_top_not_wick():
    from fvg_bot.models import Candle
    c1 = Candle(0, 92, 103, 90, 100, 1, 9)
    c2 = Candle(10, 101, 115, 98, 110, 1, 19)
    c3 = Candle(20, 112, 120, 105, 118, 1, 29)
    z = find_bullish_fvgs("X", "4H", [c1, c2, c3], min_gap_pct=0.6)[0]
    assert z.target == 118 and (z.lower, z.upper) == (103, 105)
