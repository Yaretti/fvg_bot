from fvg_bot.analysis import (
    find_bearish_fvgs, find_swings, nearest_active, pick_nearest, refresh_statuses, TfData, trend, zone_price, zone_status,
)
from fvg_bot.models import ZoneStatus, Zone, parse_klines
from tests.helpers import DOWNTREND, UPTREND, candles


def test_swings_and_uptrend():
    cs = candles(UPTREND)
    highs, lows = find_swings(cs, 1)
    assert [h for _, h in highs] == [16, 18]
    assert [l for _, l in lows] == [9, 10]
    assert trend(cs, 1).is_up


def test_downtrend_and_too_few_swings():
    assert not trend(candles(DOWNTREND), 1).is_up
    assert not trend(candles(UPTREND[:3]), 1).is_up


def test_open_candle_is_dropped():
    now_ms = 10_000
    raw = [[0, "1", "2", "1", "1", "1", 5_000], [5_001, "1", "2", "1", "1", "1", 15_000]]
    assert len(parse_klines(raw, now_ms)) == 1


def test_bearish_fvg_detection_and_bounds():
    cs = candles([(20, 25), (10, 20), (8, 12)])  # Low1=20 > High3=12
    zs = find_bearish_fvgs("AAAUSDT", "4H", cs)
    assert len(zs) == 1
    z = zs[0]
    assert (z.lower, z.upper) == (12, 20)  # межі без поправок: High3 і Low1
    assert z.id == f"AAAUSDT:4H:{cs[0].open_time}" and z.formed_at == cs[2].close_time
    assert zone_price(z, "near") == 12 and zone_price(z, "far") == 20


def test_no_fvg_when_overlap_equal_or_bullish():
    assert not find_bearish_fvgs("X", "1H", candles([(12, 15), (10, 14), (8, 12)]))  # Low1 == High3 не FVG
    assert not find_bearish_fvgs("X", "1H", candles([(10, 11), (11, 20), (15, 22)]))  # бичачий gap — не наш тип


def _zone(lower=11.0, upper=15.0):
    return Zone("id", "X", "4H", lower, upper, 0, 2)


def test_wick_into_zone_makes_it_not_untouched():
    z = _zone()  # [11, 15]
    assert zone_status(z, candles([(8, 9)]), 8.5) == ZoneStatus.UNTOUCHED
    assert zone_status(z, candles([(8, 10.9)]), 8.5) == ZoneStatus.UNTOUCHED  # тінь не дійшла до нижньої межі
    assert zone_status(z, candles([(8, 11.0)]), 8.5) == ZoneStatus.PARTIAL  # тінь торкнулась межі
    assert zone_status(z, candles([(8, 13)]), 8.5) == ZoneStatus.PARTIAL  # тінь усередині зони
    assert zone_status(z, candles([(20, 22), (14, 22)]), 21.0) == ZoneStatus.PARTIAL  # тінь зверху


def test_live_price_in_zone_is_touch():
    z = _zone()
    assert zone_status(z, candles([(8, 9)]), 12.0) == ZoneStatus.PARTIAL
    assert zone_status(z, [], 11.0) == ZoneStatus.PARTIAL


def test_filled_by_single_or_combined_wicks():
    z = _zone()
    assert zone_status(z, candles([(10, 16)]), 8.0) == ZoneStatus.FILLED
    assert zone_status(z, candles([(10, 13), (12, 16)]), 8.0) == ZoneStatus.FILLED  # разом покривають
    assert zone_status(z, candles([(10, 12), (14, 16)]), 8.0) == ZoneStatus.PARTIAL  # лишилась діра


def test_sticky_touch_and_open_candle_wick():
    cs = candles([(20, 25), (10, 20), (8, 12), (8, 11)])
    tf = TfData("4H", cs, find_bearish_fvgs("X", "4H", cs), open_candle=candles([(9, 14)])[0])
    refresh_statuses(tf, 11.0)
    assert tf.zones[0].status == ZoneStatus.PARTIAL  # тінь незакритої свічки теж враховується
    tf.open_candle = None
    refresh_statuses(tf, 11.0)
    assert tf.zones[0].status == ZoneStatus.UNTOUCHED
    refresh_statuses(tf, 11.0, touched={tf.zones[0].id})
    assert tf.zones[0].status == ZoneStatus.PARTIAL


def test_nearest_active_selection():
    far = Zone("a", "X", "4H", 20, 30, 0, 2)
    near = Zone("b", "X", "4H", 11, 15, 0, 2)
    touched = Zone("c", "X", "4H", 12, 13, 0, 2, ZoneStatus.PARTIAL)
    filled = Zone("e", "X", "4H", 12, 13, 0, 2, ZoneStatus.FILLED)
    below = Zone("d", "X", "4H", 1, 2, 0, 2)
    around = Zone("f", "X", "4H", 8, 12, 0, 2)  # ціна всередині зони — вже не «вище ціни»
    assert nearest_active([far, near, touched, filled, below, around], 9.0) is near
    assert nearest_active([touched, filled, below, around], 9.0) is None
    assert nearest_active([], 9.0) is None


def test_pick_nearest_between_timeframes():
    z1 = Zone("a", "X", "1D", 20, 30, 0, 2)
    z4 = Zone("b", "X", "4H", 11, 15, 0, 2)
    assert pick_nearest(z1, z4) is z4 and pick_nearest(z1, None) is z1 and pick_nearest(None, None) is None


def test_refresh_statuses_integration():
    cs = candles([(20, 25), (10, 20), (8, 12), (8, 11)])
    tf = TfData("4H", cs, find_bearish_fvgs("X", "4H", cs))
    refresh_statuses(tf, 11.0)
    assert tf.zones[0].status == ZoneStatus.UNTOUCHED
    refresh_statuses(tf, 13.0)  # жива ціна зайшла в зону
    assert tf.zones[0].status == ZoneStatus.PARTIAL


def test_target_is_body_top_not_wick():
    # C1: тіло 22..24, тінь до 30; C2: тіло 12..21, тінь до 26 -> ціль 24 (верх тіла), а не 30
    from fvg_bot.models import Candle
    c1 = Candle(0, 22, 30, 20, 24, 1, 9)
    c2 = Candle(10, 21, 26, 10, 12, 1, 19)
    c3 = Candle(20, 12, 13, 8, 9, 1, 29)
    z = find_bearish_fvgs("X", "4H", [c1, c2, c3])[0]
    assert z.target == 24 and (z.lower, z.upper) == (13, 20)
    # якщо вище тіло другої свічки
    c2b = Candle(10, 27, 28, 10, 12, 1, 19)
    assert find_bearish_fvgs("X", "4H", [c1, c2b, c3])[0].target == 27
