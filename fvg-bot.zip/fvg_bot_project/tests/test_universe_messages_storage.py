import os
import tempfile

from fvg_bot.config import Config
from fvg_bot.messages import fmt_price, format_message
from fvg_bot.models import Zone, ZoneStatus
from fvg_bot.storage import Storage
from fvg_bot.universe import prefilter, tradable_symbols


def _info():
    def s(sym, base, perms=("SPOT",), status="TRADING"):
        return {"symbol": sym, "baseAsset": base, "quoteAsset": "USDT", "status": status,
                "isSpotTradingAllowed": True, "permissions": list(perms)}
    return {"symbols": [s("AAAUSDT", "AAA"), s("USDCUSDT", "USDC"), s("LOWUSDT", "LOW"),
                        s("LEVUSDT", "LEV", ("LEVERAGED",)), s("OLDUSDT", "OLD", status="BREAK")]}


def _t(sym, ch, vol="5000000", price="1.5"):
    return {"symbol": sym, "priceChangePercent": str(ch), "quoteVolume": vol, "lastPrice": price}


def test_prefilter_reasons_and_sorting():
    cfg = Config()
    tickers = [_t("AAAUSDT", 9), _t("USDCUSDT", 6), _t("LOWUSDT", 7, vol="100"), _t("LEVUSDT", 8),
               _t("OLDUSDT", 10), _t("BTCETH", 20), _t("FLATUSDT", 1)]
    cands, rej, stats = prefilter(cfg, tickers, tradable_symbols(_info(), "USDT"))
    assert [c.symbol for c in cands] == ["AAAUSDT", "LOWUSDT"]
    reasons = dict(rej)
    assert "виключено" in reasons["USDCUSDT"] and "LOWUSDT" not in reasons
    assert "LEVERAGED" in reasons["LEVUSDT"] and "Spot" in reasons["OLDUSDT"]
    assert stats["below_growth"] == 1


def test_candidates_sorted_by_growth_desc():
    cfg = Config()
    info = {"symbols": [{"symbol": f"{b}USDT", "baseAsset": b, "quoteAsset": "USDT", "status": "TRADING",
                         "permissions": ["SPOT"]} for b in ("AA", "BB", "CC")]}
    cands, _, _ = prefilter(cfg, [_t("AAUSDT", 6), _t("BBUSDT", 12), _t("CCUSDT", 8)], tradable_symbols(info, "USDT"))
    assert [c.symbol for c in cands] == ["BBUSDT", "CCUSDT", "AAUSDT"]


def test_fmt_price():
    assert fmt_price(100, 2) == "100.00"
    assert fmt_price(120.0) == "120"
    assert fmt_price(0.00001234) == "0.00001234"


def test_message_format_and_not_found():
    z1 = Zone("a", "SOLUSDT", "1D", 130, 140, 0, 2, target=150)
    z4 = Zone("b", "SOLUSDT", "4H", 120, 125, 0, 2, target=135)
    msg = format_message("SOL/USDT", 100.0, 8.4, z1, z4, z4)
    assert msg.splitlines() == [
        "🟢 FVG SIGNAL", "Назва: SOL/USDT", "Поточна ціна: 100.00 USDT", "Зміна за 24 год: +8.40%",
        "Неперекритий імбаланс 1D: 130 USDT", "Неперекритий імбаланс 4H: 120 USDT",
        "Найближчий імбаланс: 120 USDT", "Ціль (максимум по тілу): 135 USDT"]
    far = format_message("SOL/USDT", 100.0, 8.4, z1, None, z1, edge="far")
    assert "1D: 140 USDT" in far and "4H: Не знайдено" in far and "Найближчий імбаланс: 140 USDT" in far
    assert "Ціль (максимум по тілу): 150 USDT" in far


def test_storage_zone_upsert_and_signal_history():
    with tempfile.TemporaryDirectory() as d:
        st = Storage(os.path.join(d, "t.db"))
        z = Zone("z1", "X", "1D", 1, 2, 5, 2)
        st.upsert_zone(z, 100)
        z.status = ZoneStatus.PARTIAL
        st.upsert_zone(z, 200)
        assert st.count("zones") == 1 and st.touched_zone_ids() == ["z1"]
        assert st.max_signal_change("X", "z1") is None
        st.record_signal("X", "z1", "m", 1.0, 5.2, True, 100)
        st.record_signal("X", "z1", "m", 1.0, 6.4, True, 101)
        assert st.max_signal_change("X", "z1") == 6.4 and st.max_signal_change("X", "other") is None
        assert st.last_signal_ts("X") == 101 and st.count("signals") == 2
        st.close()
