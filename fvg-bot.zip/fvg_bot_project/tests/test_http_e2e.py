"""Наскрізний тест без інтернету: локальний «фейковий Binance» по HTTP + справжній BinanceClient."""
import json
import os
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from fvg_bot.__main__ import main
from fvg_bot.binance import BinanceClient
from fvg_bot.config import Config
from fvg_bot.monitor import Monitor
from fvg_bot.storage import Storage
from tests.helpers import ListSender, raw_klines
from tests.test_monitor import INFO, K1D, K4H


def _serve():
    now_ms = int(time.time() * 1000)
    tickers = [
        {"symbol": "AAAUSDT", "priceChangePercent": "8.4", "lastPrice": "90", "quoteVolume": "9000000"},
        {"symbol": "USDCUSDT", "priceChangePercent": "9.0", "lastPrice": "1.0", "quoteVolume": "90000000"},
        {"symbol": "FLATUSDT", "priceChangePercent": "0.3", "lastPrice": "5", "quoteVolume": "9000000"},
    ]
    info = dict(INFO)
    info["symbols"] = INFO["symbols"] + [
        {"symbol": "USDCUSDT", "baseAsset": "USDC", "quoteAsset": "USDT", "status": "TRADING", "permissions": ["SPOT"]}]
    klines = {"1d": raw_klines(K1D, "1d", now_ms), "4h": raw_klines(K4H, "4h", now_ms)}
    hits = []

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            u = urlparse(self.path)
            q = parse_qs(u.query)
            hits.append(u.path)
            if u.path == "/api/v3/exchangeInfo":
                body = info
            elif u.path == "/api/v3/ticker/24hr":
                body = tickers
            elif u.path == "/api/v3/klines" and q["symbol"][0] == "AAAUSDT":
                body = klines[q["interval"][0]]
            else:
                self.send_response(400)
                self.end_headers()
                return
            data = json.dumps(body).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(data)

    srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_address[1]}", hits


def test_full_cycle_over_http():
    srv, url, hits = _serve()
    try:
        with tempfile.TemporaryDirectory() as d:
            cfg = Config(swing_n=1, db_path=os.path.join(d, "t.db"))
            sender = ListSender()
            m = Monitor(cfg, BinanceClient(url, retries=1), sender, Storage(cfg.db_path))
            assert m.run_once() == 1
            text = sender.sent[0]
            assert "Назва: AAA/USDT" in text and "Неперекритий імбаланс 4H: 100 USDT" in text
            assert "Ціль (максимум по тілу):" in text
            assert list(m.selected) == ["AAAUSDT"]  # USDC (стейбл) і FLAT (<5%) відсіяні
            assert m.storage.count("rejections") >= 1 and m.storage.count("zones") >= 2
            assert m.run_once() == 0  # дубліката немає
            assert "/api/v3/klines" in hits
    finally:
        srv.shutdown()


def test_cli_once_dry_run_smoke():
    srv, url, _ = _serve()
    old = {k: os.environ.get(k) for k in ("BINANCE_REST_URL", "DB_PATH", "LOG_FILE")}
    try:
        with tempfile.TemporaryDirectory() as d:
            os.environ.update(BINANCE_REST_URL=url, DB_PATH=os.path.join(d, "cli.db"), LOG_FILE="")
            assert main(["--once", "--dry-run", "--env-file", os.path.join(d, "none.env")]) == 0
    finally:
        srv.shutdown()
        for k, v in old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
