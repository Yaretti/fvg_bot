import os
import tempfile

from fvg_bot.config import Config
from fvg_bot.monitor import Monitor
from fvg_bot.storage import Storage
from tests.helpers import NOW, UPTREND, FakeClient, ListSender, raw_klines

# Бичачі FVG: 4H [100,101], 1D [105,106]; поточна ціна 90, після формування тіні в зони не заходили.
K4H = [(50, 70), (60, 80), (55, 75), (65, 90), (80, 100), (95, 120), (101, 125), (85, 99), (90, 99)]
K1D = [(55, 75), (65, 85), (60, 80), (70, 95), (85, 105), (100, 125), (106, 130), (90, 104), (95, 104)]
INFO = {"symbols": [{"symbol": "AAAUSDT", "baseAsset": "AAA", "quoteAsset": "USDT", "status": "TRADING",
                     "permissions": ["SPOT"]}]}


def _tickers(change="8.4"):
    return [{"symbol": "AAAUSDT", "priceChangePercent": change, "lastPrice": "90", "quoteVolume": "9000000"}]


def _monitor(d, k4h=K4H, k1d=K1D, change="8.4", **cfg_kw):
    klines = {("AAAUSDT", "1d"): raw_klines(k1d, "1d"), ("AAAUSDT", "4h"): raw_klines(k4h, "4h")}
    cfg = Config(swing_n=1, db_path=os.path.join(d, "t.db"), **cfg_kw)
    sender = ListSender()
    m = Monitor(cfg, FakeClient(_tickers(change), klines, INFO), sender, Storage(cfg.db_path), clock=lambda: NOW)
    return m, sender


def _set_change(m, pct, price=90.0):
    m.prices["AAAUSDT"] = price
    m.opens["AAAUSDT"] = price / (1 + pct / 100)


def test_end_to_end_signal():
    with tempfile.TemporaryDirectory() as d:
        m, sender = _monitor(d)
        assert m.run_once() == 1
        text = sender.sent[0]
        assert "Назва: AAA/USDT" in text and "Поточна ціна: 90.00 USDT" in text and "+8.40%" in text
        assert "Неперекритий імбаланс 1D: 105 USDT" in text
        assert "Неперекритий імбаланс 4H: 100 USDT" in text
        assert "Найближчий імбаланс: 100 USDT" in text
        assert "Ціль (максимум по тілу): 113 USDT" in text
        assert m.run_once() == 0 and len(sender.sent) == 1  # без дубліката


def test_step_signals_every_plus_one_percent():
    with tempfile.TemporaryDirectory() as d:
        m, sender = _monitor(d)
        m.run_once()  # 8.4%
        _set_change(m, 9.0)
        assert m.evaluate_all() == 0  # лише +0.6
        _set_change(m, 9.5)
        assert m.evaluate_all() == 1 and "+9.50%" in sender.sent[-1]
        _set_change(m, 10.2)
        assert m.evaluate_all() == 0
        _set_change(m, 10.5)
        assert m.evaluate_all() == 1
        _set_change(m, 9.0)  # відкат вниз — нових сигналів немає
        assert m.evaluate_all() == 0 and len(sender.sent) == 3


def test_no_signal_below_threshold():
    with tempfile.TemporaryDirectory() as d:
        m, sender = _monitor(d)
        m.run_once()
        _set_change(m, 4.0)
        assert m.evaluate_all() == 0 and len(sender.sent) == 1


def test_wick_in_zone_blocks_signal():
    with tempfile.TemporaryDirectory() as d:
        wick = [(50, 70), (60, 80), (55, 75), (65, 90), (80, 100), (95, 120), (101, 125), (85, 102), (90, 99)]  # high=102 торкнувся FVG [100,101]
        m, sender = _monitor(d, k4h=wick, k1d=[(8, 9)] * 9)
        assert m.run_once() == 0 and not sender.sent


def test_live_touch_is_sticky():
    with tempfile.TemporaryDirectory() as d:
        m, sender = _monitor(d)
        m.run_once()
        _set_change(m, 12.0, price=101.0)  # ціна зайшла у 4H-зону
        m.evaluate_all()
        _set_change(m, 14.0, price=90.0)  # відкотилась — зона вже «торкнута», лишається 1D-зона
        m.evaluate_all()
        assert "Неперекритий імбаланс 4H: Не знайдено" in sender.sent[-1]
        assert "Найближчий імбаланс: 105 USDT" in sender.sent[-1]


def test_touched_zones_restored_from_db():
    with tempfile.TemporaryDirectory() as d:
        m, _ = _monitor(d)
        m.run_once()
        _set_change(m, 9.0, price=13.0)
        m.evaluate_all()
        m2, sender2 = _monitor(d, k1d=[(8, 9)] * 6)
        assert m2._touched
        assert m2.run_once() == 0 and not sender2.sent


def test_no_zone_no_signal():
    with tempfile.TemporaryDirectory() as d:
        flat = [(8, 9)] * 6
        m, sender = _monitor(d, k4h=flat, k1d=flat)
        assert m.run_once() == 0 and not sender.sent


def test_required_trend_filter_rejects_downtrend_and_logs_reason():
    with tempfile.TemporaryDirectory() as d:
        flat = [(8, 9)] * 9
        m, sender = _monitor(d, k4h=flat, k1d=flat)
        assert m.run_once() == 0 and not m.selected
        assert m.storage.count("rejections") == 1


def test_failed_send_is_retried():
    with tempfile.TemporaryDirectory() as d:
        m, sender = _monitor(d)

        def boom(_):
            raise RuntimeError("network")
        good, m.sender = m.sender, type("S", (), {"send": staticmethod(boom)})()
        assert m.run_once() == 0 and m.storage.count("signals") == 0
        m.sender = good
        assert m.evaluate_all() == 1


def test_ws_message_updates_prices_and_change():
    with tempfile.TemporaryDirectory() as d:
        m, _ = _monitor(d)
        m.run_once()
        m._on_ws_message('[{"s":"AAAUSDT","c":"11","o":"10"},{"s":"BTCEUR","c":"1","o":"1"}]')
        sel = m.selected["AAAUSDT"]
        assert m.price_of(sel) == 11.0 and abs(m.change_of(sel) - 10.0) < 1e-9
        assert "BTCEUR" not in m.prices


def test_only_first_15_gainers_are_analyzed():
    with tempfile.TemporaryDirectory() as d:
        tickers = [
            {"symbol": f"C{i:02d}USDT", "priceChangePercent": str(30 - i), "lastPrice": "90", "quoteVolume": "1"}
            for i in range(20)
        ]
        info = {"symbols": [
            {"symbol": f"C{i:02d}USDT", "baseAsset": f"C{i:02d}", "quoteAsset": "USDT",
             "status": "TRADING", "permissions": ["SPOT"]}
            for i in range(20)
        ]}
        class RecordingClient(FakeClient):
            def __init__(self):
                klines = {(f"C{i:02d}USDT", tf): raw_klines(K1D if tf == "1d" else K4H, tf)
                          for i in range(20) for tf in ("1d", "4h")}
                super().__init__(tickers, klines, info)
                self.klines_symbols = []
            def klines(self, symbol, interval, limit=500):
                self.klines_symbols.append(symbol)
                return super().klines(symbol, interval, limit)
        client = RecordingClient()
        cfg = Config(swing_n=1, db_path=os.path.join(d, "t.db"))
        m = Monitor(cfg, client, ListSender(), Storage(cfg.db_path), clock=lambda: NOW)
        m.refresh_universe()
        assert list(m.selected) == [f"C{i:02d}USDT" for i in range(15)]
        assert not any(s in client.klines_symbols for s in (f"C{i:02d}USDT" for i in range(15, 20)))
