import os
import tempfile

from fvg_bot.config import Config
from fvg_bot.monitor import Monitor
from fvg_bot.storage import Storage
from tests.helpers import NOW, UPTREND, FakeClient, ListSender, raw_klines

# 4H: ведмежий gap [12,20]; 1D: gap [20,30]; ціна 11.2 нижче обох, тіней у зонах немає
K4H = [(20, 25), (10, 20), (8, 12), (8, 11), (9, 11.5)]
K1D = [(30, 40), (15, 35), (10, 20), (11, 19), (12, 19.5)]
INFO = {"symbols": [{"symbol": "AAAUSDT", "baseAsset": "AAA", "quoteAsset": "USDT", "status": "TRADING",
                     "permissions": ["SPOT"]}]}


def _tickers(change="8.4"):
    return [{"symbol": "AAAUSDT", "priceChangePercent": change, "lastPrice": "11.2", "quoteVolume": "9000000"}]


def _monitor(d, k4h=K4H, k1d=K1D, change="8.4", **cfg_kw):
    klines = {("AAAUSDT", "1d"): raw_klines(k1d, "1d"), ("AAAUSDT", "4h"): raw_klines(k4h, "4h")}
    cfg = Config(swing_n=1, db_path=os.path.join(d, "t.db"), **cfg_kw)
    sender = ListSender()
    m = Monitor(cfg, FakeClient(_tickers(change), klines, INFO), sender, Storage(cfg.db_path), clock=lambda: NOW)
    return m, sender


def _set_change(m, pct, price=11.2):
    m.prices["AAAUSDT"] = price
    m.opens["AAAUSDT"] = price / (1 + pct / 100)


def test_end_to_end_signal():
    with tempfile.TemporaryDirectory() as d:
        m, sender = _monitor(d)
        assert m.run_once() == 1
        text = sender.sent[0]
        assert "Назва: AAA/USDT" in text and "Поточна ціна: 11.20 USDT" in text and "+8.40%" in text
        assert "Неперекритий імбаланс 1D: 20 USDT" in text
        assert "Неперекритий імбаланс 4H: 12 USDT" in text
        assert "Найближчий імбаланс: 12 USDT" in text
        assert "Ціль (максимум по тілу): 22.5 USDT" in text  # верх тіла C1(25,20)->22.5 / C2 -> max
        assert m.run_once() == 0 and len(sender.sent) == 1  # без дубліката


def test_step_signals_every_plus_one_percent():
    with tempfile.TemporaryDirectory() as d:
        m, sender = _monitor(d)
        m.run_once()  # 8.4%
        _set_change(m, 9.0)
        assert m.evaluate_all() == 0  # лише +0.6
        _set_change(m, 9.5)
        assert m.evaluate_all() == 1 and "+9.50%" in sender.sent[-1]
        _set_change(m, 10.2)
        assert m.evaluate_all() == 0
        _set_change(m, 10.5)
        assert m.evaluate_all() == 1
        _set_change(m, 9.0)  # відкат вниз — нових сигналів немає
        assert m.evaluate_all() == 0 and len(sender.sent) == 3


def test_no_signal_below_threshold():
    with tempfile.TemporaryDirectory() as d:
        m, sender = _monitor(d)
        m.run_once()
        _set_change(m, 4.0)
        assert m.evaluate_all() == 0 and len(sender.sent) == 1


def test_wick_in_zone_blocks_signal():
    with tempfile.TemporaryDirectory() as d:
        wick = [(20, 25), (10, 20), (8, 12), (8, 13), (9, 11.5)]  # тінь (high=13) зайшла в зону [12,20]
        m, sender = _monitor(d, k4h=wick, k1d=[(8, 9)] * 6)
        assert m.run_once() == 0 and not sender.sent


def test_live_touch_is_sticky():
    with tempfile.TemporaryDirectory() as d:
        m, sender = _monitor(d)
        m.run_once()
        _set_change(m, 12.0, price=13.0)  # ціна зайшла у 4H-зону
        m.evaluate_all()
        _set_change(m, 14.0, price=11.0)  # відкотилась — зона вже «торкнута», лишається 1D-зона
        m.evaluate_all()
        assert "Неперекритий імбаланс 4H: Не знайдено" in sender.sent[-1]
        assert "Найближчий імбаланс: 20 USDT" in sender.sent[-1]


def test_touched_zones_restored_from_db():
    with tempfile.TemporaryDirectory() as d:
        m, _ = _monitor(d)
        m.run_once()
        _set_change(m, 9.0, price=13.0)
        m.evaluate_all()
        m2, sender2 = _monitor(d, k1d=[(8, 9)] * 6)
        assert m2._touched
        assert m2.run_once() == 0 and not sender2.sent


def test_no_zone_no_signal():
    with tempfile.TemporaryDirectory() as d:
        flat = [(8, 9)] * 6
        m, sender = _monitor(d, k4h=flat, k1d=flat)
        assert m.run_once() == 0 and not sender.sent


def test_optional_trend_filter_rejects_and_logs_reason():
    with tempfile.TemporaryDirectory() as d:
        m, sender = _monitor(d, require_trend_4h=True)
        assert m.run_once() == 0 and not m.selected
        assert m.storage.count("rejections") == 1


def test_failed_send_is_retried():
    with tempfile.TemporaryDirectory() as d:
        m, sender = _monitor(d)

        def boom(_):
            raise RuntimeError("network")
        good, m.sender = m.sender, type("S", (), {"send": staticmethod(boom)})()
        assert m.run_once() == 0 and m.storage.count("signals") == 0
        m.sender = good
        assert m.evaluate_all() == 1


def test_ws_message_updates_prices_and_change():
    with tempfile.TemporaryDirectory() as d:
        m, _ = _monitor(d)
        m.run_once()
        m._on_ws_message('[{"s":"AAAUSDT","c":"11","o":"10"},{"s":"BTCEUR","c":"1","o":"1"}]')
        sel = m.selected["AAAUSDT"]
        assert m.price_of(sel) == 11.0 and abs(m.change_of(sel) - 10.0) < 1e-9
        assert "BTCEUR" not in m.prices
