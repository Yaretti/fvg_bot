from fvg_bot.models import Candle

NOW = 1_800_000_000  # фіксований «зараз» у секундах
IV = {"1d": 86_400_000, "4h": 14_400_000, "1h": 3_600_000}


def candles(points, iv=3_600_000, end_ms=NOW * 1000):
    """points: [(low, high)] -> закриті свічки, остання закінчується до end_ms."""
    start = end_ms - len(points) * iv - 1000
    out = []
    for i, (lo, hi) in enumerate(points):
        o = start + i * iv
        out.append(Candle(o, (lo + hi) / 2, hi, lo, (lo + hi) / 2, 1.0, o + iv - 1))
    return out


def raw_klines(points, tf, end_ms=NOW * 1000):
    iv = IV[tf]
    return [
        [c.open_time, str(c.open), str(c.high), str(c.low), str(c.close), "1", c.close_time]
        for c in candles(points, iv, end_ms)
    ]


# 7 свічок (low, high), у яких при n=1 є HH (16->18) і HL (9->10)
UPTREND = [(10, 12), (11, 16), (9, 13), (10, 14), (11, 18), (10, 15), (11, 17)]
DOWNTREND = [(10, 18), (11, 17), (9, 15), (10, 14), (8, 13), (9, 12), (7, 11)]


class FakeClient:
    def __init__(self, tickers, klines, info):
        self._t, self._k, self._i = tickers, klines, info
        self.calls = 0

    def exchange_info(self):
        return self._i

    def tickers_24h(self):
        return self._t

    def klines(self, symbol, interval, limit=500):
        self.calls += 1
        return self._k[(symbol, interval)]


class ListSender:
    def __init__(self):
        self.sent = []

    def send(self, text):
        self.sent.append(text)
