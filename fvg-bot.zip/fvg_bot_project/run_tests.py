"""Запуск тестів без pytest: python run_tests.py (у CI використовується pytest)."""
import importlib, pkgutil, sys, traceback
import tests

failed = total = 0
for m in pkgutil.iter_modules(tests.__path__):
    if not m.name.startswith("test_"):
        continue
    mod = importlib.import_module(f"tests.{m.name}")
    for name in dir(mod):
        if name.startswith("test_"):
            total += 1
            try:
                getattr(mod, name)()
                print("PASS", m.name, name)
            except Exception:
                failed += 1
                print("FAIL", m.name, name)
                traceback.print_exc()
print(f"\n{total - failed}/{total} passed")
sys.exit(1 if failed else 0)
