"""Ядро: відбір монет, аналіз, оцінка зон, сигнали, WebSocket-ціни, цикли моніторингу."""
from __future__ import annotations

import asyncio
import json
import logging
import threading
import time
from dataclasses import dataclass
from typing import Callable, Optional

from .analysis import Analysis, TfData, find_bearish_fvgs, nearest_active, pick_nearest, refresh_statuses, trend
from .config import Config
from .messages import format_message
from .models import Candle, ZoneStatus, split_klines
from .storage import Storage
from .universe import prefilter, tradable_symbols

log = logging.getLogger(__name__)
HOUR_MS = 3_600_000


class Analyzer:
    """Завантажує свічки 1D і 4H. Кеш живе трохи менше за період перегляду списку."""

    def __init__(self, cfg: Config, client, clock: Callable[[], float]):
        self.cfg, self.client, self._clock = cfg, client, clock
        self._cache: dict[tuple[str, str], tuple[float, list[Candle], Optional[Candle]]] = {}

    def _candles(self, symbol: str, tf: str):
        now = self._clock()
        hit = self._cache.get((symbol, tf))
        if hit and now - hit[0] < max(30, self.cfg.universe_refresh_sec * 0.9):
            return hit[1], hit[2]
        closed, open_candle = split_klines(self.client.klines(symbol, tf, self.cfg.klines_limit), int(now * 1000))
        self._cache[(symbol, tf)] = (now, closed, open_candle)
        return closed, open_candle

    def prune(self, keep: set) -> None:
        self._cache = {k: v for k, v in self._cache.items() if k[0] in keep}

    def analyze(self, symbol: str) -> Analysis:
        c1d, open1d = self._candles(symbol, "1d")
        c4h, open4h = self._candles(symbol, "4h")
        n = self.cfg.swing_n
        return Analysis(
            symbol=symbol,
            trend_1d=trend(c1d, n),
            trend_4h=trend(c4h, n),
            tf1d=TfData("1D", c1d, find_bearish_fvgs(symbol, "1D", c1d), open1d),
            tf4h=TfData("4H", c4h, find_bearish_fvgs(symbol, "4H", c4h), open4h),
        )


@dataclass
class Selected:
    symbol: str
    display: str
    change: float
    rest_price: float
    analysis: Analysis


def trend_rejection(cfg: Config, an: Analysis) -> Optional[str]:
    if cfg.require_trend_1d and not an.trend_1d.is_up:
        return f"немає висхідної структури HH/HL на 1D ({an.trend_1d.reason})"
    if cfg.require_trend_4h and not an.trend_4h.is_up:
        return f"немає висхідної структури HH/HL на 4H ({an.trend_4h.reason})"
    return None


class Monitor:
    def __init__(self, cfg: Config, client, sender, storage: Storage, clock: Callable[[], float] = time.time):
        self.cfg, self.client, self.sender, self.storage, self._clock = cfg, client, sender, storage, clock
        self.analyzer = Analyzer(cfg, client, clock)
        self.selected: dict[str, Selected] = {}
        self.prices: dict[str, float] = {}  # живі ціни з WebSocket
        self.opens: dict[str, float] = {}
        self._tradable: Optional[dict] = None
        self._tradable_ts = 0.0
        self._saved: dict[str, str] = {}
        self._touched: set[str] = set(storage.touched_zone_ids())  # зони, яких ціна/тінь уже торкались
        self._rej_seen: dict[tuple[str, str], float] = {}
        self._lock = threading.RLock()
        self._last_bucket: Optional[int] = None
        self._last_refresh = 0.0

    # ---------- допоміжне ----------
    def _now(self) -> int:
        return int(self._clock())

    def _bucket(self) -> int:
        return int(self._clock() * 1000) // HOUR_MS

    def _reject(self, symbol: str, reason: str) -> None:
        key, now = (symbol, reason), self._clock()
        if now - self._rej_seen.get(key, 0) < 3600:
            return  # не засмічуємо журнал однаковими записами частіше ніж раз на годину
        self._rej_seen[key] = now
        log.info("Відхилено %s: %s", symbol, reason)
        self.storage.add_rejection(symbol, reason, int(now))

    def price_of(self, sel: Selected) -> float:
        return self.prices.get(sel.symbol, sel.rest_price)

    def change_of(self, sel: Selected) -> float:
        p, o = self.prices.get(sel.symbol), self.opens.get(sel.symbol)
        return (p / o - 1) * 100 if p and o else sel.change

    # ---------- відбір монет ----------
    def refresh_universe(self) -> None:
        with self._lock:
            now = self._clock()
            if self._tradable is None or now - self._tradable_ts > 6 * 3600:
                self._tradable = tradable_symbols(self.client.exchange_info(), self.cfg.quote_asset)
                self._tradable_ts = now
            tickers = self.client.tickers_24h()
            candidates, rejections, stats = prefilter(self.cfg, tickers, self._tradable)
            for sym, reason in rejections:
                self._reject(sym, reason)

            self.analyzer.prune({c.symbol for c in candidates[: self.cfg.max_candidates]})
            selected: dict[str, Selected] = {}
            for cand in candidates[: self.cfg.max_candidates]:
                if len(selected) >= self.cfg.max_coins:
                    break
                try:
                    an = self.analyzer.analyze(cand.symbol)
                except Exception as e:  # одна монета не повинна валити весь цикл
                    self._reject(cand.symbol, f"помилка завантаження даних: {e}")
                    continue
                reason = trend_rejection(self.cfg, an)
                if reason:
                    self._reject(cand.symbol, reason)
                    continue
                selected[cand.symbol] = Selected(
                    cand.symbol, f"{cand.base}/{self.cfg.quote_asset}", cand.change, cand.price, an
                )
            self.selected = selected
            self._last_bucket, self._last_refresh = self._bucket(), now
            log.info(
                "Відбір: %d пар %s, зростання <%.1f%%: %d, кандидатів: %d, пройшли всі фільтри: %d (%s)",
                stats["usdt_pairs"], self.cfg.quote_asset, self.cfg.min_change_24h, stats["below_growth"],
                len(candidates), len(selected), ", ".join(selected) or "—",
            )

    # ---------- оцінка зон і сигнали ----------
    def evaluate_all(self) -> int:
        sent = 0
        with self._lock:
            for sel in list(self.selected.values()):
                try:
                    sent += 1 if self._evaluate(sel) else 0
                except Exception:
                    log.exception("Помилка оцінки %s", sel.symbol)
        return sent

    def _persist(self, tf: TfData) -> None:
        for z in tf.zones:
            if self._saved.get(z.id) != z.status.value:
                self.storage.upsert_zone(z, self._now())
                self._saved[z.id] = z.status.value

    def _evaluate(self, sel: Selected) -> bool:
        an, price, change = sel.analysis, self.price_of(sel), self.change_of(sel)
        for tf in (an.tf1d, an.tf4h):
            refresh_statuses(tf, price, self._touched)
            for z in tf.zones:
                if z.status != ZoneStatus.UNTOUCHED:
                    self._touched.add(z.id)
            self._persist(tf)
        if change < self.cfg.min_change_24h:
            return False  # зростання впало нижче порога — не сигналізуємо
        z1, z4 = nearest_active(an.tf1d.zones, price), nearest_active(an.tf4h.zones, price)
        nearest = pick_nearest(z1, z4)
        if nearest is None:
            return False  # немає неперекритих зон вище ціни (або в зоні є тінь)

        # перший сигнал по зоні — від порога зростання; далі — щоразу, коли зростання збільшилось на крок
        last_change = self.storage.max_signal_change(sel.symbol, nearest.id)
        if last_change is not None and change < last_change + self.cfg.signal_step_pct:
            return False
        last = self.storage.last_signal_ts(sel.symbol)
        if last is not None and self._now() - last < self.cfg.signal_cooldown_sec:
            return False

        text = format_message(sel.display, price, change, z1, z4, nearest, self.cfg.quote_asset, self.cfg.show_edge)
        try:
            self.sender.send(text)
        except Exception as e:
            log.error("Не вдалося надіслати сигнал %s: %s", sel.symbol, type(e).__name__)
            return False  # не записуємо — спробуємо ще раз
        self.storage.record_signal(sel.symbol, nearest.id, text, price, change, True, self._now())
        return True

    # ---------- одноразовий прогін ----------
    def run_once(self) -> int:
        self.refresh_universe()
        return self.evaluate_all()

    # ---------- WebSocket ----------
    def _on_ws_message(self, raw: str) -> None:
        data = json.loads(raw)
        if isinstance(data, dict):
            data = data.get("data", [data])
        suffix = self.cfg.quote_asset
        for t in data:
            s = t.get("s", "")
            if s.endswith(suffix):
                self.prices[s] = float(t["c"])
                self.opens[s] = float(t["o"])

    async def _ws_loop(self) -> None:
        import websockets  # імпорт тут, щоб тести без мережі не потребували пакета

        backoff = 1
        while True:
            try:
                async with websockets.connect(self.cfg.ws_url, ping_interval=20, ping_timeout=20) as ws:
                    log.info("WebSocket підключено")
                    backoff = 1
                    async for msg in ws:
                        self._on_ws_message(msg)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("WebSocket розірвано (%s), перепідключення за %dс", type(e).__name__, backoff)
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 60)

    # ---------- цикли ----------
    async def _scheduler(self) -> None:
        while True:
            if (
                self._last_bucket is None
                or self._bucket() != self._last_bucket  # закрилась нова годинна (а можливо 4H/1D) свічка
                or self._clock() - self._last_refresh >= self.cfg.universe_refresh_sec
            ):
                await asyncio.to_thread(self.refresh_universe)
                await asyncio.to_thread(self.evaluate_all)
            await asyncio.sleep(self.cfg.candle_check_sec)

    async def _evaluator(self) -> None:
        while True:
            await asyncio.sleep(self.cfg.eval_interval_sec)
            await asyncio.to_thread(self.evaluate_all)

    async def _guard(self, name: str, fn) -> None:
        while True:
            try:
                await fn()
                return
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("Збій у циклі «%s», перезапуск через 10с", name)
                await asyncio.sleep(10)

    async def run(self, duration: Optional[float] = None) -> None:
        group = asyncio.gather(
            self._guard("websocket", self._ws_loop),
            self._guard("scheduler", self._scheduler),
            self._guard("evaluator", self._evaluator),
        )
        if duration:
            try:
                await asyncio.wait_for(group, duration)
            except asyncio.TimeoutError:
                log.info("Час тестового запуску (%ss) вичерпано — зупинка", duration)
        else:
            await group
