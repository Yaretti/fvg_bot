from __future__ import annotations

from typing import Optional

from .analysis import zone_price
from .models import Zone


def fmt_price(x: float, min_decimals: int = 0) -> str:
    s = f"{x:.8f}".rstrip("0").rstrip(".")
    dec = len(s.split(".")[1]) if "." in s else 0
    if dec < min_decimals:
        s = f"{x:.{min_decimals}f}"
    return s


def format_message(
    display: str,
    price: float,
    change_24h: float,
    z1d: Optional[Zone],
    z4h: Optional[Zone],
    nearest: Optional[Zone],
    quote: str = "USDT",
    edge: str = "near",
) -> str:
    def line(z: Optional[Zone]) -> str:
        return f"{fmt_price(zone_price(z, edge))} {quote}" if z else "Не знайдено"

    return "\n".join(
        [
            "🟢 FVG SIGNAL",
            f"Назва: {display}",
            f"Поточна ціна: {fmt_price(price, 2)} {quote}",
            f"Зміна за 24 год: {change_24h:+.2f}%",
            f"Неперекритий імбаланс 1D: {line(z1d)}",
            f"Неперекритий імбаланс 4H: {line(z4h)}",
            f"Найближчий імбаланс: {line(nearest)}",
            f"Ціль (максимум по тілу): {fmt_price(nearest.target)} {quote}" if nearest else "Ціль (максимум по тілу): Не знайдено",
        ]
    )
