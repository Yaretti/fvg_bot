"""Мінімальний клієнт публічного Binance Spot REST (без ключів, лише stdlib)."""
from __future__ import annotations

import json
import logging
import time
import urllib.error
import urllib.parse
import urllib.request

log = logging.getLogger(__name__)


class BinanceError(RuntimeError):
    pass


class BinanceClient:
    def __init__(self, base_url: str, timeout: float = 15.0, retries: int = 4):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.retries = retries

    def _get(self, path: str, params: dict | None = None):
        url = f"{self.base_url}{path}"
        if params:
            url += "?" + urllib.parse.urlencode(params)
        last: Exception | None = None
        for attempt in range(1, self.retries + 1):
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "fvg-bot/0.1"})
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    return json.loads(r.read().decode())
            except urllib.error.HTTPError as e:
                last = e
                if e.code == 451:
                    raise BinanceError("HTTP 451: Binance недоступний з цього регіону/IP") from e
                if e.code in (418, 429):
                    wait = float(e.headers.get("Retry-After", 5 * attempt))
                elif 500 <= e.code < 600:
                    wait = 2 * attempt
                else:
                    raise BinanceError(f"HTTP {e.code} для {path}") from e
            except (urllib.error.URLError, TimeoutError, ConnectionError, json.JSONDecodeError) as e:
                last = e
                wait = 2 * attempt
            log.warning("Binance %s: спроба %d/%d невдала (%s), чекаю %.0fс", path, attempt, self.retries, last, wait)
            time.sleep(wait)
        raise BinanceError(f"Не вдалося отримати {path}: {last}")

    def exchange_info(self) -> dict:
        return self._get("/api/v3/exchangeInfo")

    def tickers_24h(self) -> list:
        return self._get("/api/v3/ticker/24hr")

    def klines(self, symbol: str, interval: str, limit: int = 500) -> list:
        return self._get("/api/v3/klines", {"symbol": symbol, "interval": interval, "limit": limit})
