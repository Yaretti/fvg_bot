from __future__ import annotations

import json
import logging
import time
import urllib.error
import urllib.parse
import urllib.request

log = logging.getLogger(__name__)


class TelegramError(RuntimeError):
    pass


class TelegramSender:
    def __init__(self, token: str, chat_id: str, timeout: float = 15.0, retries: int = 3):
        if not token or not chat_id:
            raise ValueError("Потрібні TELEGRAM_BOT_TOKEN і TELEGRAM_CHAT_ID")
        self._token, self.chat_id, self.timeout, self.retries = token, chat_id, timeout, retries

    def send(self, text: str) -> None:
        url = f"https://api.telegram.org/bot{self._token}/sendMessage"
        data = urllib.parse.urlencode(
            {"chat_id": self.chat_id, "text": text, "disable_web_page_preview": "true"}
        ).encode()
        last = ""
        for attempt in range(1, self.retries + 1):
            wait = 2 * attempt
            try:
                with urllib.request.urlopen(urllib.request.Request(url, data=data), timeout=self.timeout) as r:
                    if json.loads(r.read().decode()).get("ok"):
                        return
                    last = "ok=false"
            except urllib.error.HTTPError as e:
                last = f"HTTP {e.code}"
                if e.code == 429:
                    try:
                        wait = float(json.loads(e.read().decode())["parameters"]["retry_after"]) + 1
                    except Exception:
                        wait = 10
                elif 400 <= e.code < 500:
                    raise TelegramError(f"Telegram відхилив запит: {last}") from None
            except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
                last = type(e).__name__  # без тексту винятку — він може містити URL з токеном
            log.warning("Telegram: спроба %d/%d невдала (%s)", attempt, self.retries, last)
            time.sleep(wait)
        raise TelegramError(f"Не вдалося надіслати повідомлення: {last}")


class DryRunSender:
    """Тестовий режим: нічого не відправляє, друкує повідомлення в консоль/лог."""

    def __init__(self):
        self.sent: list[str] = []

    def send(self, text: str) -> None:
        self.sent.append(text)
        log.info("[DRY-RUN] сигнал (у Telegram не надсилається):\n%s", text)
        print(f"\n=== [DRY-RUN] ===\n{text}\n=================", flush=True)
