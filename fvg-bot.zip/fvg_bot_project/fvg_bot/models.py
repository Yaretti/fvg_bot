from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class ZoneStatus(str, Enum):
    UNTOUCHED = "untouched"  # неперекрита
    PARTIAL = "partial"  # частково перекрита
    FILLED = "filled"  # повністю перекрита


@dataclass(frozen=True)
class Candle:
    open_time: int
    open: float
    high: float
    low: float
    close: float
    volume: float
    close_time: int


@dataclass
class Zone:
    id: str
    symbol: str
    timeframe: str
    lower: float  # High₃ — ближня до ціни межа (ведмежий FVG лежить над ціною)
    upper: float  # Low₁ — дальня межа
    formed_at: int  # close_time третьої свічки (мс)
    end_index: int  # індекс третьої свічки у списку свічок (не зберігається в БД)
    status: ZoneStatus = ZoneStatus.UNTOUCHED
    target: float = 0.0  # ціль: локальний максимум по ТІЛУ свічок 1–2 (не по тіні)


def parse_klines(raw: list, now_ms: int) -> list[Candle]:
    """Перетворює відповідь /klines у свічки, відкидаючи ще не закриту (close_time >= now)."""
    out = []
    for k in raw:
        c = Candle(int(k[0]), float(k[1]), float(k[2]), float(k[3]), float(k[4]), float(k[5]), int(k[6]))
        if c.close_time < now_ms:
            out.append(c)
    return out


def split_klines(raw: list, now_ms: int):
    """(закриті свічки, незакрита поточна свічка або None). Незакрита потрібна лише для перевірки тіней."""
    closed, open_candle = [], None
    for k in raw:
        c = Candle(int(k[0]), float(k[1]), float(k[2]), float(k[3]), float(k[4]), float(k[5]), int(k[6]))
        if c.close_time < now_ms:
            closed.append(c)
        else:
            open_candle = c
    return closed, open_candle
