"""Відбір монет: пре-фільтр за тікерами 24h (USDT, ріст, обсяг, виключення)."""
from __future__ import annotations

from dataclasses import dataclass

from .config import Config


@dataclass
class Candidate:
    symbol: str
    base: str
    change: float
    price: float
    quote_volume: float


def tradable_symbols(exchange_info: dict, quote: str) -> dict[str, tuple[str, bool]]:
    """symbol -> (baseAsset, is_leveraged) для пар у статусі TRADING з потрібним котируванням."""
    out = {}
    for s in exchange_info.get("symbols", []):
        if s.get("status") != "TRADING" or s.get("quoteAsset") != quote:
            continue
        if s.get("isSpotTradingAllowed") is False:
            continue
        perms = list(s.get("permissions") or [])
        for ps in s.get("permissionSets") or []:
            perms.extend(ps)
        out[s["symbol"]] = (s["baseAsset"], "LEVERAGED" in perms)
    return out


def prefilter(cfg: Config, tickers: list, tradable: dict):
    """Повертає (кандидати за спаданням росту, [(symbol, причина)], статистика)."""
    candidates: list[Candidate] = []
    rejections: list[tuple[str, str]] = []
    stats = {"usdt_pairs": 0, "below_growth": 0}
    for t in tickers:
        sym = t.get("symbol", "")
        if not sym.endswith(cfg.quote_asset):
            continue
        stats["usdt_pairs"] += 1
        try:
            change = float(t["priceChangePercent"])
            price = float(t["lastPrice"])
            qvol = float(t["quoteVolume"])
        except (KeyError, ValueError, TypeError):
            rejections.append((sym, "некоректні дані тікера"))
            continue
        if change < cfg.min_change_24h:
            stats["below_growth"] += 1
            continue
        info = tradable.get(sym)
        if info is None:
            rejections.append((sym, "пара не торгується на Spot (статус/дозволи)"))
            continue
        base, leveraged = info
        if leveraged:
            rejections.append((sym, "кредитний токен (LEVERAGED)"))
        elif base.upper() in cfg.excluded_bases:
            rejections.append((sym, f"виключено налаштуваннями ({base}: стейблкоїн/інший інструмент)"))
        elif price <= 0:
            rejections.append((sym, "нульова ціна"))
        else:
            candidates.append(Candidate(sym, base, change, price, qvol))
    candidates.sort(key=lambda c: c.change, reverse=True)
    return candidates, rejections, stats
