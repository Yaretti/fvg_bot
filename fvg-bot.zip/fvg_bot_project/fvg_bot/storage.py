from __future__ import annotations

import sqlite3
import threading
from typing import Optional

from .models import Zone

SCHEMA = """
CREATE TABLE IF NOT EXISTS zones(
  id TEXT PRIMARY KEY, symbol TEXT NOT NULL, timeframe TEXT NOT NULL,
  lower REAL NOT NULL, upper REAL NOT NULL, target REAL NOT NULL DEFAULT 0, formed_at INTEGER NOT NULL,
  status TEXT NOT NULL, first_seen INTEGER NOT NULL, updated_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_zones_symbol ON zones(symbol, timeframe);
CREATE TABLE IF NOT EXISTS signals(
  id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, zone_id TEXT NOT NULL,
  message TEXT NOT NULL, price REAL NOT NULL, change_pct REAL NOT NULL,
  created_at INTEGER NOT NULL, delivered INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_signals_zone ON signals(symbol, zone_id);
CREATE TABLE IF NOT EXISTS rejections(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, symbol TEXT NOT NULL, reason TEXT NOT NULL);
"""


class Storage:
    def __init__(self, path: str):
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._lock = threading.Lock()
        with self._lock:
            self._conn.executescript(SCHEMA)
            self._conn.commit()

    def _exec(self, sql: str, params: tuple = ()):
        with self._lock:
            cur = self._conn.execute(sql, params)
            self._conn.commit()
            return cur

    def _query(self, sql: str, params: tuple = ()):
        with self._lock:
            return self._conn.execute(sql, params).fetchall()

    def upsert_zone(self, z: Zone, now: int) -> None:
        self._exec(
            "INSERT INTO zones(id,symbol,timeframe,lower,upper,target,formed_at,status,first_seen,updated_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status, updated_at=excluded.updated_at",
            (z.id, z.symbol, z.timeframe, z.lower, z.upper, z.target, z.formed_at, z.status.value, now, now),
        )

    def touched_zone_ids(self) -> list[str]:
        return [r[0] for r in self._query("SELECT id FROM zones WHERE status != 'untouched'")]

    def max_signal_change(self, symbol: str, zone_id: str) -> Optional[float]:
        """Найбільше зростання 24г, з яким по цій зоні вже надсилався сигнал."""
        rows = self._query("SELECT MAX(change_pct) FROM signals WHERE symbol=? AND zone_id=?", (symbol, zone_id))
        return rows[0][0] if rows and rows[0][0] is not None else None

    def last_signal_ts(self, symbol: str) -> Optional[int]:
        rows = self._query("SELECT MAX(created_at) FROM signals WHERE symbol=?", (symbol,))
        return rows[0][0] if rows and rows[0][0] is not None else None

    def record_signal(self, symbol: str, zone_id: str, message: str, price: float, change: float,
                      delivered: bool, now: int) -> None:
        self._exec(
            "INSERT INTO signals(symbol,zone_id,message,price,change_pct,created_at,delivered) VALUES(?,?,?,?,?,?,?)",
            (symbol, zone_id, message, price, change, now, int(delivered)),
        )

    def add_rejection(self, symbol: str, reason: str, now: int) -> None:
        self._exec("INSERT INTO rejections(ts,symbol,reason) VALUES(?,?,?)", (now, symbol, reason))

    def count(self, table: str) -> int:
        assert table in ("zones", "signals", "rejections")
        return self._query(f"SELECT COUNT(*) FROM {table}")[0][0]

    def close(self) -> None:
        with self._lock:
            self._conn.close()
