from __future__ import annotations

import argparse
import asyncio
import logging
import logging.handlers
import sys

from .binance import BinanceClient
from .config import Config, load_dotenv
from .monitor import Monitor
from .storage import Storage
from .telegram import DryRunSender, TelegramSender


def setup_logging(cfg: Config) -> None:
    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stdout)]
    if cfg.log_file:
        handlers.append(logging.handlers.RotatingFileHandler(cfg.log_file, maxBytes=5_000_000, backupCount=3, encoding="utf-8"))
    logging.basicConfig(
        level=getattr(logging, cfg.log_level, logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=handlers,
    )


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="fvg_bot", description="FVG-сигнали для Binance Spot (без торгівлі)")
    ap.add_argument("--env-file", default=".env")
    ap.add_argument("--dry-run", action="store_true", help="не надсилати в Telegram, друкувати в консоль")
    ap.add_argument("--live", action="store_true", help="надсилати в Telegram (потрібні токен і chat id)")
    ap.add_argument("--once", action="store_true", help="один прохід (відбір + аналіз + сигнали) і вихід")
    ap.add_argument("--duration", type=float, default=None, help="працювати N секунд і вийти (для тестів)")
    args = ap.parse_args(argv)

    load_dotenv(args.env_file)
    cfg = Config.from_env()
    dry = True if args.dry_run else (False if args.live else cfg.dry_run)
    setup_logging(cfg)
    log = logging.getLogger("fvg_bot")

    if dry:
        sender = DryRunSender()
    else:
        try:
            sender = TelegramSender(cfg.telegram_token, cfg.telegram_chat_id)
        except ValueError as e:
            log.error("%s. Або запустіть з --dry-run.", e)
            return 2
    log.info("Старт: режим=%s, БД=%s", "DRY-RUN" if dry else "LIVE", cfg.db_path)

    monitor = Monitor(cfg, BinanceClient(cfg.rest_url), sender, Storage(cfg.db_path))
    try:
        if args.once:
            sent = monitor.run_once()
            log.info("Готово: відібрано монет %d, сигналів %d", len(monitor.selected), sent)
        else:
            asyncio.run(monitor.run(args.duration))
    except KeyboardInterrupt:
        log.info("Зупинено користувачем")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
