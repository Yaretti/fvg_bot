"""Чисті функції аналізу: swing-и, тренд HH/HL, бичачі FVG, статуси зон, вибір найближчої."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Sequence

from .models import Candle, Zone, ZoneStatus


# ---------- тренд ----------
@dataclass
class TrendResult:
    is_up: bool
    reason: str


def find_swings(candles: Sequence[Candle], n: int):
    """Swing high/low: екстремум суворо вищий/нижчий за n свічок ліворуч і праворуч.
    Остання n свічок swing-ами бути не можуть (ще не підтверджені).
    Повертає (highs, lows) як списки (index, price)."""
    highs, lows = [], []
    for i in range(n, len(candles) - n):
        around = [candles[j] for j in range(i - n, i + n + 1) if j != i]
        if all(candles[i].high > c.high for c in around):
            highs.append((i, candles[i].high))
        if all(candles[i].low < c.low for c in around):
            lows.append((i, candles[i].low))
    return highs, lows


def trend(candles: Sequence[Candle], n: int) -> TrendResult:
    """Висхідний тренд із гнучким підтвердженням свічками.

    Суворий варіант HH+HL приймається одразу. Якщо сформувалася лише одна
    частина структури (HH або HL), потрібні ще два підтвердження: останнє
    закриття вище закриття приблизно 5 свічок тому та ціна в верхніх 45%
    діапазону останніх 20 свічок. Це не дозволяє приймати простий відскок
    у нижній частині діапазону за висхідний тренд.
    """
    highs, lows = find_swings(candles, n)
    if len(highs) < 2 and len(lows) < 2:
        return TrendResult(False, f"недостатньо swing-ів (highs={len(highs)}, lows={len(lows)})")

    hh = len(highs) >= 2 and highs[-1][1] > highs[-2][1]
    hl = len(lows) >= 2 and lows[-1][1] > lows[-2][1]
    if hh and hl:
        return TrendResult(True, f"HH={hh}, HL={hl}, режим=strict")

    lookback = min(6, len(candles))
    momentum_up = candles[-1].close > candles[-lookback].close
    recent = candles[-min(20, len(candles)):]
    recent_low = min(c.low for c in recent)
    recent_high = max(c.high for c in recent)
    upper_half = recent_high > recent_low and candles[-1].close >= recent_low + 0.55 * (recent_high - recent_low)
    accepted = (hh or hl) and momentum_up and upper_half
    return TrendResult(
        accepted,
        f"HH={hh}, HL={hl}, momentum={momentum_up}, upper_range={upper_half}, режим={'flexible' if accepted else 'rejected'}",
    )


# ---------- FVG ----------
def find_bullish_fvgs(
    symbol: str, timeframe: str, candles: Sequence[Candle], min_gap_pct: float = 0.6
) -> list[Zone]:
    """Бичачий FVG: High₁ < Low₃ на трьох послідовних свічках.

    Зона лежить між High₁ і Low₃. Відкидаємо розриви менші за min_gap_pct
    відносно High₁. Зона зберігається без штучних поправок до її меж.
    """
    zones = []
    for i in range(len(candles) - 2):
        c1, c2, c3 = candles[i], candles[i + 1], candles[i + 2]
        if c1.high <= 0 or c1.high >= c3.low:
            continue
        gap_pct = (c3.low - c1.high) / c1.high * 100
        if gap_pct + 1e-12 < min_gap_pct:
            continue
        zones.append(
            Zone(
                id=f"{symbol}:{timeframe}:{c1.open_time}",
                symbol=symbol,
                timeframe=timeframe,
                lower=c1.high,
                upper=c3.low,
                formed_at=c3.close_time,
                end_index=i + 2,
                target=max(c1.open, c1.close, c2.open, c2.close, c3.open, c3.close),
            )
        )
    return zones


def zone_status(zone: Zone, later: Sequence[Candle], live_price: Optional[float]) -> ZoneStatus:
    """Статус зони за свічками ПІСЛЯ її формування, З УРАХУВАННЯМ ТІНЕЙ (high/low кожної свічки).

    - жодна свічка (повним діапазоном, тінню теж) і жива ціна не торкнулись зони -> UNTOUCHED
    - є дотик/тінь у зоні, але зона не покрита цілком                            -> PARTIAL
    - торкання разом покривають зону від нижньої до верхньої межі               -> FILLED
    """
    spans = []
    for c in later:
        if c.low <= zone.upper and c.high >= zone.lower:
            spans.append((max(c.low, zone.lower), min(c.high, zone.upper)))
    if live_price is not None and zone.lower <= live_price <= zone.upper:
        spans.append((live_price, live_price))
    if not spans:
        return ZoneStatus.UNTOUCHED
    spans.sort()
    cur_lo, cur_hi = spans[0]
    merged = []
    for lo, hi in spans[1:]:
        if lo <= cur_hi:
            cur_hi = max(cur_hi, hi)
        else:
            merged.append((cur_lo, cur_hi))
            cur_lo, cur_hi = lo, hi
    merged.append((cur_lo, cur_hi))
    if any(lo <= zone.lower and hi >= zone.upper for lo, hi in merged):
        return ZoneStatus.FILLED
    return ZoneStatus.PARTIAL


@dataclass
class TfData:
    timeframe: str
    candles: list[Candle]
    zones: list[Zone] = field(default_factory=list)
    open_candle: Optional[Candle] = None  # поточна незакрита свічка: використовується лише для перевірки тіней


def refresh_statuses(tf: TfData, price: Optional[float], touched: Optional[set] = None) -> None:
    """touched — id зон, яких ціна вже торкалась раніше (дотик «липкий»: untouched назад не повертається)."""
    for z in tf.zones:
        later = list(tf.candles[z.end_index + 1 :])
        if tf.open_candle is not None:
            later.append(tf.open_candle)
        z.status = zone_status(z, later, price)
        if z.status == ZoneStatus.UNTOUCHED and touched and z.id in touched:
            z.status = ZoneStatus.PARTIAL


def nearest_active(
    zones: Sequence[Zone], price: float, min_distance_pct: float = 0.0, max_distance_pct: float = 100.0
) -> Optional[Zone]:
    """Найближча неперекрита зона вище ціни в дозволеному діапазоні відстані."""
    if price <= 0:
        return None
    active = []
    for z in zones:
        if z.status != ZoneStatus.UNTOUCHED or z.lower <= price:
            continue
        distance_pct = (z.lower - price) / price * 100
        if min_distance_pct <= distance_pct <= max_distance_pct:
            active.append(z)
    return min(active, key=lambda z: z.lower) if active else None


def pick_nearest(*zones: Optional[Zone]) -> Optional[Zone]:
    present = [z for z in zones if z is not None]
    return min(present, key=lambda z: z.lower) if present else None  # при рівності — перша (1D)


def zone_price(z: Zone, edge: str = "near") -> float:
    """Ціна імбалансу в повідомленні: near = нижня межа (High₁), far = верхня (Low₃)."""
    return z.upper if edge == "far" else z.lower


@dataclass
class Analysis:
    symbol: str
    trend_1d: TrendResult
    trend_4h: TrendResult
    tf1d: TfData
    tf4h: TfData
