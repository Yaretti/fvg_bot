"""Чисті функції аналізу: swing-и, тренд HH/HL, бичачі FVG, статуси зон, вибір найближчої."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Sequence

from .models import Candle, Zone, ZoneStatus


# ---------- тренд ----------
@dataclass
class TrendResult:
    is_up: bool
    reason: str


def find_swings(candles: Sequence[Candle], n: int):
    """Swing high/low: екстремум суворо вищий/нижчий за n свічок ліворуч і праворуч.
    Остання n свічок swing-ами бути не можуть (ще не підтверджені).
    Повертає (highs, lows) як списки (index, price)."""
    highs, lows = [], []
    for i in range(n, len(candles) - n):
        around = [candles[j] for j in range(i - n, i + n + 1) if j != i]
        if all(candles[i].high > c.high for c in around):
            highs.append((i, candles[i].high))
        if all(candles[i].low < c.low for c in around):
            lows.append((i, candles[i].low))
    return highs, lows


def trend(candles: Sequence[Candle], n: int) -> TrendResult:
    """Висхідний тренд: останній swing high > попереднього (HH) І останній swing low > попереднього (HL)."""
    highs, lows = find_swings(candles, n)
    if len(highs) < 2 or len(lows) < 2:
        return TrendResult(False, f"недостатньо swing-ів (highs={len(highs)}, lows={len(lows)})")
    hh = highs[-1][1] > highs[-2][1]
    hl = lows[-1][1] > lows[-2][1]
    return TrendResult(hh and hl, f"HH={hh}, HL={hl}")


# ---------- FVG ----------
def find_bearish_fvgs(symbol: str, timeframe: str, candles: Sequence[Candle]) -> list[Zone]:
    """Ведмежий FVG (імбаланс після різкого падіння): Low₁ > High₃ на трьох послідовних свічках.
    Зона: нижня межа = High₃, верхня = Low₁. Межі без жодних поправок.
    Ціль руху (інформативно): верх тіла найвищої зі свічок 1–2."""
    zones = []
    for i in range(len(candles) - 2):
        c1, c2, c3 = candles[i], candles[i + 1], candles[i + 2]
        if c1.low > c3.high:
            zones.append(
                Zone(
                    id=f"{symbol}:{timeframe}:{c1.open_time}",
                    symbol=symbol,
                    timeframe=timeframe,
                    lower=c3.high,
                    upper=c1.low,
                    formed_at=c3.close_time,
                    end_index=i + 2,
                    # локальний максимум перед падінням — по тілу (open/close), а не по тіні
                    target=max(c1.open, c1.close, c2.open, c2.close),
                )
            )
    return zones


def zone_status(zone: Zone, later: Sequence[Candle], live_price: Optional[float]) -> ZoneStatus:
    """Статус зони за свічками ПІСЛЯ її формування, З УРАХУВАННЯМ ТІНЕЙ (high/low кожної свічки).

    - жодна свічка (повним діапазоном, тінню теж) і жива ціна не торкнулись зони -> UNTOUCHED
    - є дотик/тінь у зоні, але зона не покрита цілком                            -> PARTIAL
    - торкання разом покривають зону від нижньої до верхньої межі               -> FILLED
    """
    spans = []
    for c in later:
        if c.low <= zone.upper and c.high >= zone.lower:
            spans.append((max(c.low, zone.lower), min(c.high, zone.upper)))
    if live_price is not None and zone.lower <= live_price <= zone.upper:
        spans.append((live_price, live_price))
    if not spans:
        return ZoneStatus.UNTOUCHED
    spans.sort()
    cur_lo, cur_hi = spans[0]
    merged = []
    for lo, hi in spans[1:]:
        if lo <= cur_hi:
            cur_hi = max(cur_hi, hi)
        else:
            merged.append((cur_lo, cur_hi))
            cur_lo, cur_hi = lo, hi
    merged.append((cur_lo, cur_hi))
    if any(lo <= zone.lower and hi >= zone.upper for lo, hi in merged):
        return ZoneStatus.FILLED
    return ZoneStatus.PARTIAL


@dataclass
class TfData:
    timeframe: str
    candles: list[Candle]
    zones: list[Zone] = field(default_factory=list)
    open_candle: Optional[Candle] = None  # поточна незакрита свічка: використовується лише для перевірки тіней


def refresh_statuses(tf: TfData, price: Optional[float], touched: Optional[set] = None) -> None:
    """touched — id зон, яких ціна вже торкалась раніше (дотик «липкий»: untouched назад не повертається)."""
    for z in tf.zones:
        later = list(tf.candles[z.end_index + 1 :])
        if tf.open_candle is not None:
            later.append(tf.open_candle)
        z.status = zone_status(z, later, price)
        if z.status == ZoneStatus.UNTOUCHED and touched and z.id in touched:
            z.status = ZoneStatus.PARTIAL


def nearest_active(zones: Sequence[Zone], price: float) -> Optional[Zone]:
    """Найближча НЕПЕРЕКРИТА зона (жодної тіні в ній), що цілком лежить вище поточної ціни."""
    active = [z for z in zones if z.status == ZoneStatus.UNTOUCHED and z.lower > price]
    return min(active, key=lambda z: z.lower) if active else None


def pick_nearest(*zones: Optional[Zone]) -> Optional[Zone]:
    present = [z for z in zones if z is not None]
    return min(present, key=lambda z: z.lower) if present else None  # при рівності — перша (1D)


def zone_price(z: Zone, edge: str = "near") -> float:
    """Ціна імбалансу в повідомленні: near = ближня межа (High₃), far = дальня (Low₁)."""
    return z.upper if edge == "far" else z.lower


@dataclass
class Analysis:
    symbol: str
    trend_1d: TrendResult
    trend_4h: TrendResult
    tf1d: TfData
    tf4h: TfData
