"""Конфігурація з env / .env. Секрети (токен Telegram) — тільки з середовища."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

DEFAULT_EXCLUDED_BASES = (
    "USDC,FDUSD,TUSD,BUSD,DAI,USDP,USDD,EUR,AEUR,EURI,GBP,TRY,BRL,"
    "USDE,USD1,PYUSD,XUSD,BFUSD,RLUSD,UST,USTC,SUSD,GUSD,LUSD,PAXG,XAUT,WBTC,WBETH,BNSOL"
)


def load_dotenv(path: str = ".env") -> None:
    """Мінімальний .env-лоадер (не перезаписує вже задані змінні середовища)."""
    p = Path(path)
    if not p.is_file():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def _get(name: str, default: str) -> str:
    v = os.environ.get(name)
    return default if v is None or v == "" else v


def _bool(name: str, default: bool) -> bool:
    return _get(name, str(default)).strip().lower() in ("1", "true", "yes", "on")


@dataclass(frozen=True)
class Config:
    telegram_token: str = ""
    telegram_chat_id: str = ""
    dry_run: bool = True  # True: повідомлення лише у лог/консоль, у Telegram не йдуть

    # Binance: data-api.binance.vision віддає лише публічні ринкові дані і працює з GitHub-раннерів
    rest_url: str = "https://data-api.binance.vision"
    ws_url: str = "wss://data-stream.binance.vision/ws/!miniTicker@arr"
    quote_asset: str = "USDT"

    # відбір монет
    min_change_24h: float = 5.0
    max_coins: int = 15
    min_quote_volume: float = 2_000_000.0  # мінімальний 24h обсяг у USDT
    max_candidates: int = 80  # скільки кандидатів максимум аналізуємо, щоб набрати max_coins
    excluded_bases: frozenset = frozenset(DEFAULT_EXCLUDED_BASES.split(","))

    # аналіз
    require_trend_1d: bool = False  # HH/HL за замовчуванням вимкнено (приклади — відскок після спаду)
    require_trend_4h: bool = False
    swing_n: int = 2  # свічок з кожного боку для swing high/low
    klines_limit: int = 500

    # періодичність
    universe_refresh_sec: int = 300
    candle_check_sec: int = 20
    eval_interval_sec: int = 15
    signal_cooldown_sec: int = 0  # мін. пауза між сигналами по одній монеті (0 = без паузи)
    signal_step_pct: float = 1.0  # повторний сигнал по тій самій зоні, коли зростання за 24г збільшилось на цей крок
    show_edge: str = "near"  # яку межу зони показувати: near = High₃ (ближня до ціни), far = Low₁

    db_path: str = "fvg_bot.sqlite3"
    log_level: str = "INFO"
    log_file: str = ""

    @classmethod
    def from_env(cls) -> "Config":
        excluded = {s.strip().upper() for s in _get("EXCLUDED_BASES", DEFAULT_EXCLUDED_BASES).split(",") if s.strip()}
        return cls(
            telegram_token=_get("TELEGRAM_BOT_TOKEN", ""),
            telegram_chat_id=_get("TELEGRAM_CHAT_ID", ""),
            dry_run=_bool("DRY_RUN", True),
            rest_url=_get("BINANCE_REST_URL", cls.rest_url).rstrip("/"),
            ws_url=_get("BINANCE_WS_URL", cls.ws_url),
            quote_asset=_get("QUOTE_ASSET", "USDT").upper(),
            min_change_24h=float(_get("MIN_CHANGE_24H", "5")),
            max_coins=int(_get("MAX_COINS", "15")),
            min_quote_volume=float(_get("MIN_QUOTE_VOLUME", "2000000")),
            max_candidates=int(_get("MAX_CANDIDATES", "80")),
            excluded_bases=frozenset(excluded),
            require_trend_1d=_bool("REQUIRE_TREND_1D", False),
            require_trend_4h=_bool("REQUIRE_TREND_4H", False),
            swing_n=int(_get("SWING_N", "2")),
            klines_limit=int(_get("KLINES_LIMIT", "500")),
            universe_refresh_sec=int(_get("UNIVERSE_REFRESH_SEC", "300")),
            candle_check_sec=int(_get("CANDLE_CHECK_SEC", "20")),
            eval_interval_sec=int(_get("EVAL_INTERVAL_SEC", "15")),
            signal_cooldown_sec=int(_get("SIGNAL_COOLDOWN_SEC", "0")),
            signal_step_pct=float(_get("SIGNAL_STEP_PCT", "1")),
            show_edge=_get("SHOW_EDGE", "near").lower(),
            db_path=_get("DB_PATH", "fvg_bot.sqlite3"),
            log_level=_get("LOG_LEVEL", "INFO").upper(),
            log_file=_get("LOG_FILE", ""),
        )
